﻿namespace CRUDDemo.Models
{
    public class Employee

    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float Salary {  get; set; }
        public String Gender {  get; set; }
        public String Address { get; set; }

    }
}
